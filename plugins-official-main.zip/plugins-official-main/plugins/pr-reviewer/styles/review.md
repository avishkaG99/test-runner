# PR Review Output Style Guide

This file defines the formatting and tone conventions for all output produced by the `pr-review` plugin agents.

---

## General Principles

- Be **direct and specific** — every finding must reference a file path and line number
- Be **actionable** — every issue must include a concrete fix or suggestion
- Be **proportionate** — severity labels must match actual impact, not be inflated
- Be **balanced** — always acknowledge what was done well, not only what is wrong
- Avoid filler phrases: "Great job!", "This is interesting", "As an AI..."

---

## Severity Levels

Use these labels consistently across all agents:

| Label | When to use |
|---|---|
| `CRITICAL` | Security vulnerabilities, data loss risk, broken functionality, blocks merge |
| `WARNING` | Non-blocking but should be fixed before merge — correctness, reliability concerns |
| `SUGGESTION` | Nice-to-have improvements — style, readability, minor optimisation |
| `POSITIVE` | Specific call-outs of good practices worth noting |

---

## Finding Format

Every finding must follow this structure:

```
- `path/to/file.ext:LINE` — Short title of the issue

  **Why:** One sentence explaining the problem or risk.

  **Fix:**
  ```language
  // concrete corrected code
  ```
```

- File path is always relative to the repo root
- Line number is always included (`:LINE`)
- The fix block always uses a fenced code block with the correct language tag
- If a fix is not a code change (e.g. a config or process issue), use plain text after **Fix:**

---

## GitHub Suggestion Blocks

For findings with an exact, drop-in code fix, add a native suggestion block immediately after the `**Fix:**` block. The review lead carries this through to the GitHub PR inline comment as a native "Apply suggestion" / "Commit suggestion" button. Azure DevOps ignores these — there is no equivalent API mechanism.

Format for a **single-line replacement** (replaces only the flagged line):

    <!-- suggestion: line NN -->
    ```suggestion
    [exact replacement for line NN, indentation preserved verbatim]
    ```

Format for a **multi-line replacement** (replaces a consecutive block of lines):

    <!-- suggestion: lines NN-MM -->
    ```suggestion
    [exact verbatim lines replacing NN through MM, indentation preserved]
    ```

The HTML comment carries the line range (the posting loop parses it to set `start_line`/`line` in the GitHub API call); the ` ```suggestion ` fence is what GitHub renders as the button. This format must stay in sync with the agent files and `commands/pr-review.md`.

**Include** when the fix is a concrete, unambiguous swap: wrong identifier, missing null guard, insecure function replaced by its safe equivalent, N+1 query replaced by a batched call, sequential async calls made parallel, etc.

**Do not include** when: the fix is architectural or design-level, requires author judgment, involves non-consecutive lines, or spans more than ~10 lines.

The suggestion code is applied **verbatim** by GitHub — indentation must exactly match the file (tabs or spaces, correct nesting level).

---

## Verdict Labels

The final PR verdict must be one of exactly **four** values, rendered as inline code, in uppercase with no decoration (no ✅, no parentheses, no variants like `APPROVED WITH SUGGESTIONS`). The provider files map each value to a platform vote — any other string causes the vote step to be skipped silently.

| Verdict | Meaning |
|---|---|
| `APPROVE` | No critical issues and no warnings |
| `APPROVE WITH SUGGESTIONS` | No critical issues and no warnings — only suggestions. Still posted as a non-blocking vote |
| `REQUEST CHANGES` | One or more critical issues must be resolved before merge |
| `NEEDS DISCUSSION` | At least one warning that needs author input, but no hard blockers |

> This set must stay in sync with `styles/report-template.md`, `providers/github.md`, `providers/azure-devops.md`, and `skills/post-review/SKILL.md`. Do not add or rename values in one place without updating the others.

---

## Section Order

The compiled PR review report must follow this section order:

1. Header (PR title, author, file counts, verdict)
2. Summary (2–3 sentences)
3. Critical Issues
4. Warnings
5. Suggestions
6. Review Details (Code Quality / Security / Test Coverage / Performance)
7. Files Reviewed (table)

Do not reorder or omit sections. If a section has no findings, write:
> *No [critical issues / warnings / suggestions] found.*

---

## Code Snippets

- Always use fenced code blocks with the language tag matching the file being reviewed (e.g. ` ```ts `, ` ```cs `, ` ```py `, ` ```go `, ` ```java `)
- Do not default to TypeScript — use the language of the actual file in the PR
- Show the **before** (problematic) and **after** (fixed) when the fix is non-obvious
- Keep snippets focused — show only the relevant lines, not entire functions
- Use `// ...` (or the appropriate comment syntax for the language) to indicate omitted lines

Example (language will vary per PR):

    // Before
    [problematic code in the detected language]

    // After
    [corrected code in the detected language]

---

## Risk Rating (Files Reviewed Table)

Use these emoji indicators in the Files Reviewed table:

| Emoji | Risk level | When to use |
|---|---|---|
| 🔴 | High | Auth, payments, DB migrations, public API surface |
| 🟡 | Medium | Business logic, data transformations, external integrations |
| 🟢 | Low | Utilities, config, docs, tests, formatting |

---

## Tone

- Use **second person** when addressing the author: "Consider extracting…", "This could be simplified…"
- Avoid passive voice: say "this will cause a SQL injection" not "a SQL injection may occur"
- Be concise — a finding should rarely exceed 5 lines of prose
- Positive observations should be specific: "Clean separation of concerns in `AuthService`" not "Nice code"
