# Provider: Azure DevOps

Use this provider when `git remote get-url origin` contains `dev.azure.com` or `visualstudio.com`.

## Prerequisites

The Azure DevOps REST API is called directly via `curl` using a Personal Access Token (PAT).

Required environment variable:

| Variable | Purpose |
|---|---|
| `AZURE-DEVOPS-TOKEN` | Azure DevOps PAT — must include `Code (Read & Write)`, `Work Items (Read & Write)`, and `Pull Request Threads (Read & Write)`. `Work Items` is unused for `trigger_mode=schedule` (no work item exists) but the PAT can still carry the scope. |

Optional — used to override values parsed from the remote URL:

| Variable | Default |
|---|---|
| `AZURE_ORG` | Parsed from remote URL |
| `AZURE_PROJECT` | Parsed from remote URL |
| `AZURE_REPO` | Parsed from remote URL |

---

## Parsing the Remote URL

**Modern format:** `https://dev.azure.com/{org}/{project}/_git/{repo}`

```bash
REMOTE=$(git remote get-url origin)
AZURE_ORG=$(echo   "$REMOTE" | sed 's|https://dev.azure.com/||' | cut -d'/' -f1)
AZURE_PROJECT=$(echo "$REMOTE" | sed 's|https://dev.azure.com/||' | cut -d'/' -f2)
AZURE_REPO=$(echo  "$REMOTE" | sed 's|.*/_git/||' | sed 's|\.git$||')
```

**Legacy format:** `https://{org}.visualstudio.com/{project}/_git/{repo}`

```bash
AZURE_ORG=$(echo   "$REMOTE" | sed 's|https://||' | cut -d'.' -f1)
AZURE_PROJECT=$(echo "$REMOTE" | cut -d'/' -f4)
AZURE_REPO=$(echo  "$REMOTE" | sed 's|.*/_git/||' | sed 's|\.git$||')
```

### API Base URL

```bash
if [[ "$REMOTE" =~ \.visualstudio\.com ]]; then
  API_BASE="https://${AZURE_ORG}.visualstudio.com/${AZURE_PROJECT}"
else
  API_BASE="https://dev.azure.com/${AZURE_ORG}/${AZURE_PROJECT}"
fi
```

Use `${API_BASE}` in place of a hardcoded host for **every** API call below.

---

## Checking for an already-open scheduled PR

**`trigger_mode=schedule` only** (orchestrator Step 1a). Query active PRs targeting the default branch and filter for a source branch starting with `perf/scheduled-`:

```bash
EXISTING_SCHEDULED_PR=$(curl -s -u ":${AZURE-DEVOPS-TOKEN}" \
  "${API_BASE}/_apis/git/repositories/${AZURE_REPO}/pullrequests?searchCriteria.status=active&searchCriteria.targetRefName=refs/heads/${DEFAULT_BRANCH}&api-version=7.1" \
  | python3 -c "
import sys, json
prs = json.load(sys.stdin).get('value', [])
match = next((pr for pr in prs if pr['sourceRefName'].startswith('refs/heads/perf/scheduled-')), None)
print(match['pullRequestId'] if match else '')
")

if [ -n "${EXISTING_SCHEDULED_PR}" ]; then
  EXISTING_PR_URL="${API_BASE}/_git/${AZURE_REPO}/pullrequest/${EXISTING_SCHEDULED_PR}"
  echo "Skipped: performance PR ${EXISTING_PR_URL} from a prior scheduled run is still open — review or merge it before the next scheduled optimization PR is opened."
  exit 0
fi
```

Run this **before** Step 0 (indexing) so a run with an already-open scheduled PR does no analysis work at all — not just no PR-opening work.

---

## Recovering the last scheduled baseline SHA

**`trigger_mode=schedule` only** (orchestrator Step 1a). Recover `LAST_SCAN_SHA` — the baseline of the most recent prior scheduled run in **any** state — to drive the incremental scan window (orchestrator Step 1b). Query PRs with `searchCriteria.status=all`, take the most recent `perf/scheduled-*` one, and parse the trailing short SHA from its source branch name (falling back to the description's `Trigger:` line):

```bash
LAST_SCAN_SHA=$(curl -s -u ":${AZURE-DEVOPS-TOKEN}" \
  "${API_BASE}/_apis/git/repositories/${AZURE_REPO}/pullrequests?searchCriteria.status=all&searchCriteria.targetRefName=refs/heads/${DEFAULT_BRANCH}&\$top=100&api-version=7.1" \
  | python3 -c "
import sys, json, re
prs = json.load(sys.stdin).get('value', [])
sched = [pr for pr in prs if pr['sourceRefName'].startswith('refs/heads/perf/scheduled-')]
sched.sort(key=lambda pr: pr['creationDate'])
sha = ''
if sched:
    last = sched[-1]
    m = re.match(r'refs/heads/perf/scheduled-\d{8}-([0-9a-f]+)\$', last['sourceRefName'])
    if m:
        sha = m.group(1)
    else:
        m = re.search(r'Trigger: Scheduled run @ ([0-9a-f]+)', last.get('description', ''))
        sha = m.group(1) if m else ''
print(sha)
")

# Degrade to a full scan if the SHA is missing or gone from history
if [ -z "${LAST_SCAN_SHA}" ] || ! git cat-file -e "${LAST_SCAN_SHA}^{commit}" 2>/dev/null; then
  LAST_SCAN_SHA=""
fi
```

An empty `LAST_SCAN_SHA` means the orchestrator resolves `SCAN_MODE=full` (Step 1b). Never fail the run over unrecoverable state — a full scan is always a valid fallback.

---

## Reading the trigger work item

The orchestrator receives the work item title / description via the rule payload. If you need to re-read it (e.g. local runs), use:

```bash
curl -s -u ":${AZURE-DEVOPS-TOKEN}" \
  "https://dev.azure.com/${AZURE_ORG}/_apis/wit/workitems/${WORKITEM_ID}?\$expand=fields&api-version=7.1" \
  | python3 -c "
import sys, json
wi = json.load(sys.stdin)
print(json.dumps({
  'id': wi['id'],
  'title': wi['fields']['System.Title'],
  'description': wi['fields'].get('System.Description', ''),
  'tags': wi['fields'].get('System.Tags', '')
}))"
```

Parse lines matching `^\s*Scope:` and `^\s*Target:` (case-insensitive) from the description.

---

## Markdown in PR / work-item threads

This plugin posts via the **Git** [Pull Request Threads](https://learn.microsoft.com/en-us/rest/api/azure/devops/git/pull-request-threads/create?view=azure-devops-rest-7.1) API for pull requests, and the **Work Item Comments** API for the originating work item. Put Markdown in `content` / `comments[].content` and set thread `properties` on PR threads so the web UI renders Markdown:

| Key | Value |
|---|---|
| `Microsoft.TeamFoundation.Discussion.SupportsMarkdown` | `1` (integer) |

Include the same `properties` object on **every** PR `POST .../threads` body below.

---

## Posting the Starting Comment on the work item

**Skip this section entirely when `TRIGGER_MODE=schedule`** — there is no work item to comment on.

Post a comment on the originating work item so the reporter knows the Performance Optimizer has started **and which scope it committed to**. The comment must echo the orchestrator's resolved run plan — never the raw work-item body — so reviewers can catch scope drift before the PR is opened.

Populate these variables from the orchestrator's resolved run plan:

- `SCOPE_RESOLVED`   — literal scope string or `full codebase` if no hint was given
- `TARGET_RESOLVED`  — literal target runtime (`api` / `worker` / `frontend` / `data`) or `none`
- `DEFAULT_BRANCH`   — e.g. `main`
- `BASELINE_SHA`     — short SHA of `origin/${DEFAULT_BRANCH}` at review start
- `FILE_COUNT`       — number of files that survived scope filtering

```bash
# Compose JSON safely — work-item comments accept HTML; \n is rendered as a line break.
BODY=$(jq -n \
  --arg branch "${DEFAULT_BRANCH}" \
  --arg sha    "${BASELINE_SHA}" \
  --arg scope  "${SCOPE_RESOLVED}" \
  --arg target "${TARGET_RESOLVED}" \
  --arg files  "${FILE_COUNT}" \
  '{text: ("Performance review in progress.\n\n" +
           "Running a whole-codebase performance review covering latency, CPU, memory, and I/O patterns. " +
           "A pull request with focused, low-risk optimizations and the embedded report will be linked here when complete.\n\n" +
           "Run plan:\n" +
           "- Default branch: " + $branch + " @ " + $sha + "\n" +
           "- Scope: " + $scope + "\n" +
           "- Target runtime: " + $target + "\n" +
           "- Files in scope: " + $files)}')

curl -s -u ":${AZURE-DEVOPS-TOKEN}" \
  -X POST \
  -H "Content-Type: application/json" \
  "https://dev.azure.com/${AZURE_ORG}/${AZURE_PROJECT}/_apis/wit/workItems/${WORKITEM_ID}/comments?api-version=7.1-preview.3" \
  -d "${BODY}"
```

If posting fails, output a single warning line and continue — never stop the review. However, do **not** skip resolving `SCOPE_RESOLVED` / `TARGET_RESOLVED` / `BASELINE_SHA` just because the comment failed: those values are reused in the PR report header and must match.

---

## Creating the pull request

Enter this section **only** after the `perf-pr-author` agent has applied Quick-win findings on a new branch and pushed it.

### 1. Push the optimization branch

Performed by `perf-pr-author`:

```bash
git push -u origin "${NEW_BRANCH}"
```

### 2. Create the PR via REST

Title and body both depend on `TRIGGER_MODE`. Work-item runs open a **full-report** PR; scheduled runs open a **slim single-change** PR (see `agents/perf-pr-author.md`, *Body for `schedule`*).

```bash
if [ "${TRIGGER_MODE}" = "schedule" ]; then
  RUN_DATE_DISPLAY=$(date -u +%Y-%m-%d)
  PR_TITLE="perf: scheduled optimization scan (${RUN_DATE_DISPLAY})"
else
  PR_TITLE="perf: ${WORKITEM_TITLE}"
fi

curl -s -u ":${AZURE-DEVOPS-TOKEN}" \
  -X POST \
  -H "Content-Type: application/json" \
  "${API_BASE}/_apis/git/repositories/${AZURE_REPO}/pullrequests?api-version=7.1" \
  -d "$(python3 -c "
import json, os
print(json.dumps({
  'sourceRefName': f\"refs/heads/{os.environ['NEW_BRANCH']}\",
  'targetRefName': f\"refs/heads/{os.environ['DEFAULT_BRANCH']}\",
  'title': os.environ['PR_TITLE'],
  'description': os.environ['PR_BODY_MARKDOWN']
}))
")"
```

`${PR_BODY_MARKDOWN}` is the pre-assembled body string. Its contents differ by mode:

**`trigger_mode=workitem` — full report:**

1. Summary paragraph describing the PR as the automated response to the work item
2. Traceability: `Related work item: #${WORKITEM_ID}` and an `AB#${WORKITEM_ID}` smart commit reference (for Azure Boards auto-linking)
3. Applied-optimizations table
4. Not-applied list (or "None")
5. Verification checklist (literal `- [ ]` items)
6. `## Performance Report` heading followed by the full, already-compiled report body

**`trigger_mode=schedule` — slim single-change:**

1. Summary paragraph (1–2 sentences): automated scheduled (cron) scan, no work item, one small low-risk change; further findings arrive as separate PRs on later ticks
2. Traceability: a `Trigger: Scheduled run @ ${BASELINE_SHA}` line followed by a `Scan window: ${SCAN_WINDOW}` line (`<last-sha>..<baseline-sha>` for an incremental scan, `full @ <baseline-sha>` for a full one) — there is no work item to reference
3. `## The optimization` heading followed by the compact single-change block (`file:lines` / category / why / before-after / how-to-verify)
4. Verification checklist (literal `- [ ]` items — the short scheduled variant)

Do **not** include an applied-optimizations table, a not-applied list, or the `## Performance Report` block on a scheduled run.

Capture the returned `pullRequestId` and construct the web URL:

```
${API_BASE}/_git/${AZURE_REPO}/pullrequest/<new-pr-id>
```

### 3. Link the PR back to the work item

**Skip this step entirely when `TRIGGER_MODE=schedule`** — there is no work item to comment on. Go straight to Step 4.

Post a comment thread on the originating work item pointing to the new PR:

```bash
curl -s -u ":${AZURE-DEVOPS-TOKEN}" \
  -X POST \
  -H "Content-Type: application/json" \
  "https://dev.azure.com/${AZURE_ORG}/${AZURE_PROJECT}/_apis/wit/workItems/${WORKITEM_ID}/comments?api-version=7.1-preview.3" \
  -d "$(python3 -c "
import json, os
print(json.dumps({'text': f\"Performance PR opened with focused, low-risk optimizations: {os.environ['NEW_PR_URL']}\"}))
")"
```

Optionally attach the PR to the work item as a `Pull Request` artifact link via the Work Item Updates API — this surfaces the PR directly on the work item card in Azure Boards.

### 4. Output

```bash
if [ "${TRIGGER_MODE}" = "schedule" ]; then
  echo "Performance PR opened: ${NEW_PR_URL} — targets ${DEFAULT_BRANCH}, scheduled run @ ${BASELINE_SHA}"
else
  echo "Performance PR opened: ${NEW_PR_URL} — targets ${DEFAULT_BRANCH}, linked to work item #${WORKITEM_ID}"
fi
```

If the REST call fails (missing scope, branch policy, duplicate PR), emit one error line and stop. Do **not** retry with different auth. Do **not** rewrite the default branch.
