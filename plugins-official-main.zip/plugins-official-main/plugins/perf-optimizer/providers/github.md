# Provider: GitHub

Use this provider when `git remote get-url origin` contains `github.com`.

## How this fits with the rest of the plugin

- **Reading / analysis** — uses **git** against the repository's default branch. No `gh` is needed to fetch files; the analyzer operates on the full working tree.
- **GitHub-specific** — `gh` is used to (a) read the trigger issue body (`trigger_mode=issue` only), (b) post a "review in progress" comment on the issue (`issue` only), (c) check for an already-open scheduled PR (`trigger_mode=schedule` only), (d) open the pull request, and (e) post a link-back comment on the issue after the PR is open (`issue` only).

## Prerequisites

- **GitHub CLI** (`gh`) installed: https://cli.github.com
- Authenticated: `gh auth login`, or non-interactive `GH_TOKEN` / `GITHUB-TOKEN`

**Token scopes / permissions:**

| Permission | Access | Purpose |
|---|---|---|
| **Contents** | Read & Write | Read repository code, push the new `perf/issue-*` / `perf/scheduled-*` branch |
| **Metadata** | Read | Resolve repository metadata (default branch, etc.) |
| **Issues** | Read & Write | `trigger_mode=issue` only — read the trigger issue body / scope hints and post a link-back comment. Not used for scheduled runs. |
| **Pull requests** | Read & Write | Open the optimization PR, list open PRs for the scheduled-run dedupe check, and update it with the report |

For classic tokens: `repo` (private repos) or `public_repo` (public only); `read:org` if the repository is under an organization.

The plugin does **not** use the GitHub MCP server.

---

## Resolving `owner` and `repo`

```bash
REMOTE=$(git remote get-url origin)
# https://github.com/org/repo.git  →  owner=org  repo=repo
# git@github.com:org/repo.git      →  owner=org  repo=repo
OWNER=$(echo "$REMOTE" | sed 's|https://github.com/||;s|git@github.com:||' | cut -d'/' -f1)
REPO=$(echo  "$REMOTE" | sed 's|https://github.com/||;s|git@github.com:||' | cut -d'/' -f2 | sed 's|\.git$||')
```

---

## Checking for an already-open scheduled PR

**`trigger_mode=schedule` only** (orchestrator Step 1a). `gh` has no server-side "filter by head branch prefix" flag, so list open PRs against the default branch and filter client-side:

```bash
EXISTING_SCHEDULED_PR=$(gh pr list \
  --base "${DEFAULT_BRANCH}" \
  --state open \
  --json headRefName,url \
  --jq '[.[] | select(.headRefName | startswith("perf/scheduled-"))][0].url // ""')

if [ -n "${EXISTING_SCHEDULED_PR}" ]; then
  echo "Skipped: performance PR ${EXISTING_SCHEDULED_PR} from a prior scheduled run is still open — review or merge it before the next scheduled optimization PR is opened."
  exit 0
fi
```

Run this **before** Step 0 (indexing) so a run with an already-open scheduled PR does no analysis work at all — not just no PR-opening work.

---

## Recovering the last scheduled baseline SHA

**`trigger_mode=schedule` only** (orchestrator Step 1a). Recover `LAST_SCAN_SHA` — the baseline of the most recent prior scheduled run in **any** state (open, merged, or closed) — to drive the incremental scan window (orchestrator Step 1b). Primary source is the head branch name; fall back to the PR body's `Trigger:` line if the branch name doesn't parse:

```bash
LAST_SCAN_SHA=$(gh pr list \
  --base "${DEFAULT_BRANCH}" \
  --state all \
  --limit 100 \
  --json headRefName,createdAt \
  --jq '[.[] | select(.headRefName | startswith("perf/scheduled-"))]
        | sort_by(.createdAt) | last | .headRefName // ""' \
  | sed -nE 's|^perf/scheduled-[0-9]{8}-([0-9a-f]+)$|\1|p')

if [ -z "${LAST_SCAN_SHA}" ]; then
  # Fallback: most recent scheduled PR's body trigger line
  LAST_SCAN_SHA=$(gh pr list \
    --base "${DEFAULT_BRANCH}" \
    --state all \
    --limit 100 \
    --json headRefName,createdAt,body \
    --jq '[.[] | select(.headRefName | startswith("perf/scheduled-"))]
          | sort_by(.createdAt) | last | .body // ""' \
    | sed -nE 's/^Trigger: Scheduled run @ ([0-9a-f]+).*/\1/p' | head -1)
fi

# Degrade to a full scan if the SHA is missing or gone from history
if [ -z "${LAST_SCAN_SHA}" ] || ! git cat-file -e "${LAST_SCAN_SHA}^{commit}" 2>/dev/null; then
  LAST_SCAN_SHA=""
fi
```

An empty `LAST_SCAN_SHA` means the orchestrator resolves `SCAN_MODE=full` (Step 1b). Never fail the run over unrecoverable state — a full scan is always a valid fallback.

---

## Reading the trigger issue body (for scope / target hints)

The orchestrator receives the issue body via the rule payload. If you need to re-read it (for example when running the command locally after the webhook fired), use:

```bash
gh issue view "${ISSUE_NUMBER}" --json title,body,labels \
  --jq '{title, body, labels: [.labels[].name]}'
```

Parse lines matching `^\s*Scope:` and `^\s*Target:` (case-insensitive) from the issue body.

---

## Posting the "review in progress" comment

The starting comment must be **transparent about what was parsed** from the issue. The reporter should be able to read this single comment and know, before the review finishes, exactly which scope the agent decided to run under. This closes the loop on silent scope / target drift.

Populate these fields from the orchestrator's resolved run plan (not from the raw issue body — use the values the orchestrator actually committed to):

- `SCOPE_RESOLVED`   — literal scope string or `full codebase` if no hint was given
- `TARGET_RESOLVED`  — literal target runtime (`api` / `worker` / `frontend` / `data`) or `none`
- `DEFAULT_BRANCH`   — e.g. `main`
- `BASELINE_SHA`     — short SHA of `origin/${DEFAULT_BRANCH}` at review start
- `FILE_COUNT`       — number of files that survived scope filtering

```bash
gh issue comment "${ISSUE_NUMBER}" --body "$(cat <<EOF
Performance review in progress

Running a whole-codebase performance review covering latency, CPU, memory, and I/O patterns. A pull request with focused, low-risk optimizations and the embedded report will be linked here when complete — this may take a few minutes.

**Run plan**
- Default branch: \`${DEFAULT_BRANCH}\` @ \`${BASELINE_SHA}\`
- Scope: ${SCOPE_RESOLVED}
- Target runtime: ${TARGET_RESOLVED}
- Files in scope: ${FILE_COUNT}
EOF
)"
```

If posting fails, output one warning line and continue — but do **not** attempt to proceed without resolving `SCOPE_RESOLVED` / `TARGET_RESOLVED` / `BASELINE_SHA` first. Those values are reused in the PR body and must be consistent between the starting comment and the final report.

---

## Opening the pull request

Enter this section **only** after the `perf-pr-author` agent has committed Quick-win findings and pushed the `perf/issue-*` branch.

### 1. Push the optimization branch

Performed by `perf-pr-author`:

```bash
git push -u origin "${NEW_BRANCH}"
```

### 2. Create the PR

Title, body shape, and traceability all depend on `TRIGGER_MODE`. Issue/work-item runs open a **full-report** PR; scheduled runs open a **slim single-change** PR (see `agents/perf-pr-author.md`, *Body for `schedule`*). Resolve the title, then build the matching body.

**Full-report body (`trigger_mode=issue` / `workitem`):**

```bash
PR_TITLE="perf: ${ISSUE_TITLE}"

gh pr create \
  --base  "${DEFAULT_BRANCH}" \
  --head  "${NEW_BRANCH}" \
  --title "${PR_TITLE}" \
  --body  "$(cat <<EOF
## Summary

Automated response to issue #${ISSUE_NUMBER} from the Performance Optimizer. Contains focused, low-risk performance optimizations applied across the codebase based on a whole-repository analysis of the default branch.

Closes #${ISSUE_NUMBER}

## Applied optimizations

${APPLIED_TABLE}

## Not applied

${NOT_APPLIED_LIST:-"_None — all selected Quick-wins applied cleanly._"}

## Verification checklist

- [ ] Unit tests pass locally / in CI
- [ ] Integration tests pass locally / in CI
- [ ] Manual smoke test on the affected hot paths
- [ ] Before/after measurement captured for at least one High-impact item
- [ ] No behavior change intended — API contracts unchanged

## Performance Report

${REPORT_BODY}

---

_Generated by the Performance Optimizer._
EOF
)"
```

The `${REPORT_BODY}` substitution is the full, already-compiled report body produced by the orchestrator per `styles/report-template.md`.

**Slim single-change body (`trigger_mode=schedule`):**

There is no `${REPORT_BODY}` and no applied-optimizations table — the body describes the one change only. `${OPTIMIZATION_BLOCK}` is the compact `file:lines / category / why / before-after / how-to-verify` block `perf-pr-author` assembled for the single finding. `${SCAN_WINDOW}` is the range the scan actually covered, frozen by the orchestrator in Step 1b-iv — `<last-sha>..<baseline-sha>` for an incremental scan, `full @ <baseline-sha>` for a full one.

```bash
RUN_DATE_DISPLAY=$(date -u +%Y-%m-%d)
PR_TITLE="perf: scheduled optimization scan (${RUN_DATE_DISPLAY})"

gh pr create \
  --base  "${DEFAULT_BRANCH}" \
  --head  "${NEW_BRANCH}" \
  --title "${PR_TITLE}" \
  --body  "$(cat <<EOF
## Summary

Automated scheduled (cron) performance scan — no originating issue or work item. This scan surfaced a single low-risk optimization, applied here as one small, easy-to-review change. Further findings, if any, will arrive as separate PRs on later scheduled runs.

Trigger: Scheduled run @ ${BASELINE_SHA}
Scan window: ${SCAN_WINDOW}

## The optimization

${OPTIMIZATION_BLOCK}

## Verification checklist

- [ ] Tests pass locally / in CI
- [ ] Change is behavior-preserving (no API/contract change)
- [ ] Diff reviewed in full (it is intentionally small)

---

_Generated by the Performance Optimizer (scheduled run)._
EOF
)"
```

### 3. Link the PR back to the issue

**Skip this step entirely when `TRIGGER_MODE=schedule`** — there is no issue to comment on. Go straight to Step 4.

```bash
NEW_PR_URL=$(gh pr view "${NEW_BRANCH}" --json url --jq .url)

gh issue comment "${ISSUE_NUMBER}" --body "Performance PR opened with focused, low-risk optimizations: ${NEW_PR_URL}"
```

### 4. Output

```bash
NEW_PR_URL=$(gh pr view "${NEW_BRANCH}" --json url --jq .url)
if [ "${TRIGGER_MODE}" = "schedule" ]; then
  echo "Performance PR opened: ${NEW_PR_URL} — targets ${DEFAULT_BRANCH}, scheduled run @ ${BASELINE_SHA}"
else
  echo "Performance PR opened: ${NEW_PR_URL} — targets ${DEFAULT_BRANCH}, closes issue #${ISSUE_NUMBER}"
fi
```

If `gh pr create` fails (branch protection, missing scope, pre-existing PR on the branch), emit one error line and stop. Do **not** force-push, do **not** rewrite the default branch.
