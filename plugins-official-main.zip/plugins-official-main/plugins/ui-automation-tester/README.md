---
title: UI Automation Tester
description: TODO
---

The **UI Automation Tester** plugin is a work in progress.

TODO: describe purpose, commands, and workflow.
